DELIMITER $$

DROP FUNCTION IF EXISTS `card_verify`;

-- Returns 1 in case number is incorrect, 0 if is correct or -1 if number is NULL
CREATE FUNCTION `card_verify`(number VARCHAR(32)) RETURNS INT(11)
BEGIN
    DECLARE i, sum, r, weight INT;

    IF (number IS NULL) THEN
        RETURN -1;
    END IF;

    SET weight = 1;
    SET sum = 0;
    SET i = length(number);

    WHILE i > 0 DO
        SET r = substring(number, i, 1) * weight;
        SET sum = sum + IF(r > 9, r - 9, r);
        SET i = i - 1;
        SET weight = 3 - weight;
    END WHILE;

    IF (sum % 10 = 0) THEN
        RETURN 0;
    ELSE
        RETURN 1;
    END IF;
END$$

DELIMITER ;